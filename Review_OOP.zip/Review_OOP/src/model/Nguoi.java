package model;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Nguoi {
	private String name;
	private Date birthDay;
	private String identityCard;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getBirthDay() {
		return birthDay;
	}

	public void setBirthDay(Date birthDay) {
		this.birthDay = birthDay;
	}

	public String getIdentityCard() {
		return identityCard;
	}

	public void setIdentityCard(String identityCard) {
		this.identityCard = identityCard;
	}

	public Nguoi() {

	}

	public Nguoi(String name, Date birthDay, String identityCard) {
		this.name = name;
		this.birthDay = birthDay;
		this.identityCard = identityCard;
	}

	public void nhapThongTin(Scanner sc) {
		System.out.print("Nhap ho va ten khach hang: ");
		this.name = sc.nextLine();
		System.out.println("Nhap ngay sinh(dd-mm-yyyy): ");
		String ns = sc.nextLine();
		this.birthDay = chuyenStringDate(ns);
		System.out.print("Nhap so chung minh nhan dan: ");
		this.identityCard = sc.nextLine();
	}

	public void hienThongTin() {
		System.out.println("Ho va Ten: " + this.name);
		System.out.println("Ngay sinh: " + this.birthDay);
		System.out.println("So chung minh nhan dan: " + this.identityCard);
	}

	public Date chuyenStringDate(String str) {
		Date ns = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		try {
			ns = sdf.parse(str);
		} catch (Exception e) {
			System.out.println("Loi dinh dang thoi gian.!");
		}
		return ns;
	}

	public String getSoCMND() {
		return this.identityCard;
	}
}